using System.Diagnostics;
using System.Runtime.InteropServices;

namespace SoundButton;

internal static class NativeMethods
{
    [DllImport("user32.dll")]
    internal static extern IntPtr GetForegroundWindow();

    [DllImport("user32.dll")]
    internal static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);

    [DllImport("user32.dll")]
    internal static extern bool SetForegroundWindow(IntPtr hWnd);

    [DllImport("user32.dll")]
    internal static extern short GetAsyncKeyState(int vKey);

    /// <summary>このアプリ自身のウィンドウが前面にあるか。</summary>
    internal static bool IsOwnProcessForeground()
    {
        var h = GetForegroundWindow();
        if (h == IntPtr.Zero) return false;
        GetWindowThreadProcessId(h, out var pid);
        return pid == (uint)Environment.ProcessId;
    }
}

/// <summary>
/// 低レベルキーボードフック(WH_KEYBOARD_LL)。
/// ・「バックグラウンドでのキー入力」がオンで、割り当てキーが1つ以上あるときだけフックを入れる
/// ・割り当てたキーと一致しない入力は、その場で破棄する(記録・保存・送信しない)
/// ・キー入力は握りつぶさず、他のアプリにそのまま渡す
/// </summary>
internal sealed class GlobalKeyHook : IDisposable
{
    private const int WH_KEYBOARD_LL = 13;
    private const int WM_KEYDOWN = 0x0100, WM_KEYUP = 0x0101, WM_SYSKEYDOWN = 0x0104, WM_SYSKEYUP = 0x0105;
    private const int VK_SHIFT = 0x10, VK_CONTROL = 0x11, VK_MENU = 0x12, VK_LWIN = 0x5B, VK_RWIN = 0x5C;

    private delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);

    [StructLayout(LayoutKind.Sequential)]
    private struct KBDLLHOOKSTRUCT
    {
        public uint vkCode;
        public uint scanCode;
        public uint flags;
        public uint time;
        public UIntPtr dwExtraInfo;
    }

    [DllImport("user32.dll", SetLastError = true)]
    private static extern IntPtr SetWindowsHookEx(int idHook, LowLevelKeyboardProc lpfn, IntPtr hMod, uint dwThreadId);

    [DllImport("user32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool UnhookWindowsHookEx(IntPtr hhk);

    [DllImport("user32.dll")]
    private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode)]
    private static extern IntPtr GetModuleHandle(string? lpModuleName);

    private readonly LowLevelKeyboardProc _proc;   // GC対策で保持
    private IntPtr _hook = IntPtr.Zero;
    private HashSet<string> _combos = new(StringComparer.Ordinal);
    private HashSet<string> _baseCodes = new(StringComparer.Ordinal);
    private readonly HashSet<string> _down = new(StringComparer.Ordinal);  // 押下中の「割り当てキー」だけ(リピート判定用)

    /// <summary>割り当てキーが押されたとき(combo, repeat)。UIスレッドで呼ばれます。</summary>
    public event Action<string, bool>? ComboPressed;

    public GlobalKeyHook() => _proc = HookProc;

    /// <summary>設定を反映します。UIスレッドから呼んでください。</summary>
    public void Configure(bool enabled, IEnumerable<string> combos)
    {
        var set = new HashSet<string>(combos.Where(c => !string.IsNullOrEmpty(c) && c != "!"), StringComparer.Ordinal);
        _combos = set;
        _baseCodes = new HashSet<string>(set.Select(c => c[(c.LastIndexOf('+') + 1)..]), StringComparer.Ordinal);
        _down.Clear();

        if (enabled && set.Count > 0) Install();
        else Uninstall();
    }

    private void Install()
    {
        if (_hook != IntPtr.Zero) return;
        _hook = SetWindowsHookEx(WH_KEYBOARD_LL, _proc, GetModuleHandle(null), 0);
    }

    private void Uninstall()
    {
        if (_hook == IntPtr.Zero) return;
        UnhookWindowsHookEx(_hook);
        _hook = IntPtr.Zero;
    }

    private IntPtr HookProc(int nCode, IntPtr wParam, IntPtr lParam)
    {
        if (nCode >= 0)
        {
            try
            {
                int msg = wParam.ToInt32();
                bool isDown = msg == WM_KEYDOWN || msg == WM_SYSKEYDOWN;
                bool isUp = msg == WM_KEYUP || msg == WM_SYSKEYUP;

                var k = Marshal.PtrToStructure<KBDLLHOOKSTRUCT>(lParam);
                var code = KeyMap.ToCode(k.vkCode, k.scanCode, (k.flags & 0x01) != 0);

                // 割り当てキー以外は、ここで何も残さず終了
                if (code != null && _baseCodes.Contains(code))
                {
                    if (isUp)
                    {
                        _down.Remove(code);
                    }
                    else if (isDown)
                    {
                        bool repeat = !_down.Add(code);
                        var combo = BuildCombo(code);
                        if (combo != null && _combos.Contains(combo))
                            ComboPressed?.Invoke(combo, repeat);
                    }
                }
            }
            catch
            {
                // フック内では例外を外に出さない
            }
        }
        return CallNextHookEx(IntPtr.Zero, nCode, wParam, lParam);
    }

    /// <summary>HTML側 comboOf() と同じルール: 修飾キーは Ctrl / Alt / Shift のうち1つまで、Winキーは不可。</summary>
    private static string? BuildCombo(string code)
    {
        static bool Down(int vk) => (NativeMethods.GetAsyncKeyState(vk) & 0x8000) != 0;

        if (Down(VK_LWIN) || Down(VK_RWIN)) return null;
        bool ctrl = Down(VK_CONTROL), alt = Down(VK_MENU), shift = Down(VK_SHIFT);
        int n = (ctrl ? 1 : 0) + (alt ? 1 : 0) + (shift ? 1 : 0);
        if (n > 1) return null;
        if (ctrl) return "Ctrl+" + code;
        if (alt) return "Alt+" + code;
        if (shift) return "Shift+" + code;
        return code;
    }

    public void Dispose() => Uninstall();
}

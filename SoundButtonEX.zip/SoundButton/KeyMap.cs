namespace SoundButton;

/// <summary>
/// Windowsのスキャンコードを、ブラウザの KeyboardEvent.code 形式("KeyA", "Digit1", "F5" など)に変換します。
/// HTML側(comboOf)が保存しているキー名と同じ形式です。
/// </summary>
internal static class KeyMap
{
    private static readonly Dictionary<int, string> Normal = new();
    private static readonly Dictionary<int, string> Extended = new()
    {
        [0x1C] = "NumpadEnter",
        [0x1D] = "ControlRight",
        [0x35] = "NumpadDivide",
        [0x37] = "PrintScreen",
        [0x38] = "AltRight",
        [0x45] = "NumLock",
        [0x47] = "Home",
        [0x48] = "ArrowUp",
        [0x49] = "PageUp",
        [0x4B] = "ArrowLeft",
        [0x4D] = "ArrowRight",
        [0x4F] = "End",
        [0x50] = "ArrowDown",
        [0x51] = "PageDown",
        [0x52] = "Insert",
        [0x53] = "Delete",
        [0x5B] = "MetaLeft",
        [0x5C] = "MetaRight",
        [0x5D] = "ContextMenu",
    };

    static KeyMap()
    {
        Normal[0x01] = "Escape";
        for (int i = 0; i < 9; i++) Normal[0x02 + i] = "Digit" + (i + 1);
        Normal[0x0B] = "Digit0";
        Normal[0x0C] = "Minus";
        Normal[0x0D] = "Equal";
        Normal[0x0E] = "Backspace";
        Normal[0x0F] = "Tab";

        const string row1 = "QWERTYUIOP", row2 = "ASDFGHJKL", row3 = "ZXCVBNM";
        for (int i = 0; i < row1.Length; i++) Normal[0x10 + i] = "Key" + row1[i];
        for (int i = 0; i < row2.Length; i++) Normal[0x1E + i] = "Key" + row2[i];
        for (int i = 0; i < row3.Length; i++) Normal[0x2C + i] = "Key" + row3[i];

        Normal[0x1A] = "BracketLeft";
        Normal[0x1B] = "BracketRight";
        Normal[0x1C] = "Enter";
        Normal[0x1D] = "ControlLeft";
        Normal[0x27] = "Semicolon";
        Normal[0x28] = "Quote";
        Normal[0x29] = "Backquote";
        Normal[0x2A] = "ShiftLeft";
        Normal[0x2B] = "Backslash";
        Normal[0x33] = "Comma";
        Normal[0x34] = "Period";
        Normal[0x35] = "Slash";
        Normal[0x36] = "ShiftRight";
        Normal[0x37] = "NumpadMultiply";
        Normal[0x38] = "AltLeft";
        Normal[0x39] = "Space";
        Normal[0x3A] = "CapsLock";

        for (int i = 0; i < 10; i++) Normal[0x3B + i] = "F" + (i + 1);   // F1-F10
        Normal[0x57] = "F11";
        Normal[0x58] = "F12";
        for (int i = 0; i < 11; i++) Normal[0x64 + i] = "F" + (13 + i);  // F13-F23
        Normal[0x76] = "F24";

        Normal[0x45] = "NumLock";
        Normal[0x46] = "ScrollLock";
        Normal[0x47] = "Numpad7";
        Normal[0x48] = "Numpad8";
        Normal[0x49] = "Numpad9";
        Normal[0x4A] = "NumpadSubtract";
        Normal[0x4B] = "Numpad4";
        Normal[0x4C] = "Numpad5";
        Normal[0x4D] = "Numpad6";
        Normal[0x4E] = "NumpadAdd";
        Normal[0x4F] = "Numpad1";
        Normal[0x50] = "Numpad2";
        Normal[0x51] = "Numpad3";
        Normal[0x52] = "Numpad0";
        Normal[0x53] = "NumpadDecimal";

        // 日本語キーボード等
        Normal[0x56] = "IntlBackslash";
        Normal[0x70] = "KanaMode";
        Normal[0x73] = "IntlRo";
        Normal[0x79] = "Convert";
        Normal[0x7B] = "NonConvert";
        Normal[0x7D] = "IntlYen";
    }

    public static string? ToCode(uint vkCode, uint scanCode, bool extended)
    {
        if (vkCode == 0x13) return "Pause";          // VK_PAUSE(スキャンコードが特殊)
        if (scanCode == 0) return null;
        var table = extended ? Extended : Normal;
        return table.TryGetValue((int)scanCode, out var code) ? code : null;
    }
}

@echo off
cd /d "%~dp0"
echo SoundButton EX をビルドします...
dotnet publish SoundButton.csproj -c Release -o publish
if errorlevel 1 (
  echo ビルドに失敗しました。
  pause
  exit /b 1
)
echo.
echo 完成: %~dp0publish\SoundButtonEX.exe
pause

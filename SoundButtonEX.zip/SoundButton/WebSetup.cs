using System.Diagnostics;
using System.Reflection;
using Microsoft.Web.WebView2.Core;

namespace SoundButton;

/// <summary>WebView2の共通設定。Web フォルダの中身をexeから仮想ホストで配信します。</summary>
internal static class WebSetup
{
    public const string Host = "soundbutton.example";
    public const string Origin = "https://" + Host;
    public const string HomeUrl = Origin + "/index.html";

    private static readonly Lazy<Dictionary<string, string>> Resources = new(() =>
    {
        var map = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var name in Assembly.GetExecutingAssembly().GetManifestResourceNames())
            if (name.StartsWith("web/", StringComparison.OrdinalIgnoreCase))
                map[name[4..].Replace('\\', '/')] = name;
        return map;
    });

    public static bool IsOwn(string? uri) =>
        uri != null && (uri.Equals(Origin, StringComparison.OrdinalIgnoreCase) ||
                        uri.StartsWith(Origin + "/", StringComparison.OrdinalIgnoreCase));

    private static bool IsHome(string uri)
    {
        if (!Uri.TryCreate(uri, UriKind.Absolute, out var u)) return false;
        var p = u.AbsolutePath;
        return p == "/" || p.Equals("/index.html", StringComparison.OrdinalIgnoreCase);
    }

    public static void OpenExternal(string? url)
    {
        if (!Uri.TryCreate(url, UriKind.Absolute, out var u)) return;
        if (u.Scheme is not ("http" or "https" or "mailto")) return;
        try { Process.Start(new ProcessStartInfo(u.AbsoluteUri) { UseShellExecute = true }); }
        catch { /* ブラウザが開けなくても無視 */ }
    }

    private static string Mime(string path) => Path.GetExtension(path).ToLowerInvariant() switch
    {
        ".html" or ".htm" => "text/html; charset=utf-8",
        ".js" or ".mjs" => "text/javascript; charset=utf-8",
        ".css" => "text/css; charset=utf-8",
        ".json" => "application/json; charset=utf-8",
        ".webmanifest" => "application/manifest+json; charset=utf-8",
        ".png" => "image/png",
        ".jpg" or ".jpeg" => "image/jpeg",
        ".webp" => "image/webp",
        ".svg" => "image/svg+xml",
        ".ico" => "image/x-icon",
        ".woff2" => "font/woff2",
        ".woff" => "font/woff",
        ".ttf" => "font/ttf",
        ".mp3" => "audio/mpeg",
        ".wav" => "audio/wav",
        _ => "application/octet-stream",
    };

    /// <param name="openPopup">window.open された自サイトのページ(規約など)を開く処理</param>
    /// <param name="onNavigateHome">ポップアップ内で「アプリへ戻る」が押されたときの処理(メイン窓はnull)</param>
    public static void Configure(CoreWebView2 core, Action<string> openPopup, Action? onNavigateHome = null)
    {
        var s = core.Settings;
        s.IsStatusBarEnabled = false;
        s.IsZoomControlEnabled = false;
        s.IsPasswordAutosaveEnabled = false;
        s.IsGeneralAutofillEnabled = false;
#if DEBUG
        s.AreDevToolsEnabled = true;
#else
        s.AreDevToolsEnabled = false;
        s.AreBrowserAcceleratorKeysEnabled = false;   // F5/Ctrl+Rなどで割り当てキーとぶつからないように
#endif

        core.AddWebResourceRequestedFilter(Origin + "/*", CoreWebView2WebResourceContext.All);
        core.WebResourceRequested += OnResourceRequested;

        core.NavigationStarting += (_, e) =>
        {
            var uri = e.Uri;
            if (IsOwn(uri))
            {
                if (onNavigateHome != null && IsHome(uri)) { e.Cancel = true; onNavigateHome(); }
                return;
            }
            if (uri.StartsWith("about:", StringComparison.OrdinalIgnoreCase) ||
                uri.StartsWith("blob:", StringComparison.OrdinalIgnoreCase) ||
                uri.StartsWith("data:", StringComparison.OrdinalIgnoreCase)) return;

            e.Cancel = true;
            OpenExternal(uri);
        };

        core.NewWindowRequested += (_, e) =>
        {
            e.Handled = true;
            if (IsOwn(e.Uri)) openPopup(e.Uri);
            else OpenExternal(e.Uri);
        };
    }

    private static void OnResourceRequested(object? sender, CoreWebView2WebResourceRequestedEventArgs e)
    {
        var core = (CoreWebView2)sender!;
        var uri = new Uri(e.Request.Uri);
        var path = Uri.UnescapeDataString(uri.AbsolutePath).TrimStart('/');
        if (path.Length == 0) path = "index.html";

        bool methodOk = e.Request.Method is "GET" or "HEAD";
        if (methodOk && !path.Contains("..") && Resources.Value.TryGetValue(path, out var resName))
        {
            var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(resName);
            if (stream != null)
            {
                e.Response = core.Environment.CreateWebResourceResponse(
                    stream, 200, "OK", $"Content-Type: {Mime(path)}\r\nCache-Control: no-cache");
                return;
            }
        }
        e.Response = core.Environment.CreateWebResourceResponse(
            null, 404, "Not Found", "Content-Type: text/plain; charset=utf-8");
    }
}

using System.Text.Json;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace SoundButton;

public sealed class MainForm : Form
{
    // HTML側が期待している window.electronApp を、WebView2用に提供するスクリプト
    private const string BridgeScript = """
        (() => {
          const listeners = [];
          const send = m => window.chrome.webview.postMessage(m);
          window.electronApp = {
            isWindowsApp: true,
            setBackgroundKeys: (enabled, keys) =>
              send({ type: 'bgkeys', enabled: !!enabled, keys: Array.isArray(keys) ? keys.map(String) : [] }),
            onGlobalKey: cb => { if (typeof cb === 'function') listeners.push(cb); },
            openExternal: url => send({ type: 'open', url: String(url) })
          };
          window.chrome.webview.addEventListener('message', e => {
            const d = e.data;
            if (d && d.type === 'key')
              for (const f of listeners) { try { f({ combo: d.combo, repeat: !!d.repeat }); } catch (_) {} }
          });
        })();
        """;

    // 初回の選択を、ページの設定(sb_play.bg)に一度だけ反映する。以降は設定画面の値が優先される
    private static string InitialSettingScript(bool bg) => $$"""
        (() => { try {
          if (!localStorage.getItem('sb_bg_init')) {
            const p = JSON.parse(localStorage.getItem('sb_play') || '{}');
            p.bg = {{(bg ? "true" : "false")}};
            localStorage.setItem('sb_play', JSON.stringify(p));
            localStorage.setItem('sb_bg_init', '1');
          }
        } catch (_) {} })();
        """;

    private readonly WebView2 _web = new()
    {
        Dock = DockStyle.Fill,
        DefaultBackgroundColor = Color.FromArgb(11, 13, 17),
    };
    private readonly GlobalKeyHook _hook = new();
    private readonly string? _startLink;
    private readonly bool _initialBackground;
    private readonly NotifyIcon _tray;
    private CoreWebView2Environment? _env;
    private bool _bgEnabled;   // ページ側の「バックグラウンドでのキー入力」設定(オンなら × でトレイへ)
    private bool _exiting;

    public MainForm(string? startLink, bool initialBackground)
    {
        _startLink = startLink;
        _initialBackground = initialBackground;

        Text = "SoundButton EX";
        BackColor = Color.FromArgb(11, 13, 17);
        ClientSize = new Size(1280, 820);
        MinimumSize = new Size(480, 600);
        StartPosition = FormStartPosition.CenterScreen;
        try { Icon = Icon.ExtractAssociatedIcon(Environment.ProcessPath!); } catch { }

        var menu = new ContextMenuStrip();
        menu.Items.Add("開く", null, (_, _) => ShowFromTray());
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("終了", null, (_, _) => ExitApp());
        _tray = new NotifyIcon
        {
            Icon = Icon ?? SystemIcons.Application,
            Text = "SoundButton EX",
            ContextMenuStrip = menu,
            Visible = true,
        };
        _tray.MouseClick += (_, e) => { if (e.Button == MouseButtons.Left) ShowFromTray(); };

        Controls.Add(_web);
        _hook.ComboPressed += OnCombo;
        Shown += async (_, _) => await InitWebAsync();
        FormClosed += (_, _) =>
        {
            _hook.Dispose();
            _tray.Visible = false;   // 終了後にアイコンが残らないように
            _tray.Dispose();
        };
    }

    /// <summary>「×」: バックグラウンド動作がオンならトレイに隠れて動き続け、オフなら終了します。</summary>
    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        if (!_exiting && e.CloseReason == CloseReason.UserClosing && _bgEnabled)
        {
            e.Cancel = true;
            Hide();
            _tray.ShowBalloonTip(4000, "SoundButton EX",
                "バックグラウンドで動作しています。\n終了するには、タスクトレイのアイコンを右クリックして「終了」を選んでください。",
                ToolTipIcon.Info);
            return;
        }
        base.OnFormClosing(e);
    }

    private void ShowFromTray()
    {
        Show();
        if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal;
        Activate();
    }

    private void ExitApp()
    {
        _exiting = true;
        Close();
    }

    private async Task InitWebAsync()
    {
        try
        {
            var dataDir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "SoundButton", "WebView2");

            // 最小化中や他アプリ使用中でも、音がすぐ鳴るようにする
            var options = new CoreWebView2EnvironmentOptions(
                "--autoplay-policy=no-user-gesture-required " +
                "--disable-background-timer-throttling " +
                "--disable-renderer-backgrounding " +
                "--disable-backgrounding-occluded-windows");

            _env = await CoreWebView2Environment.CreateAsync(null, dataDir, options);
            await _web.EnsureCoreWebView2Async(_env);
        }
        catch (WebView2RuntimeNotFoundException)
        {
            MessageBox.Show(this,
                "Microsoft Edge WebView2 ランタイムが見つかりません。\nインストール後に、もう一度起動してください。",
                "SoundButton EX", MessageBoxButtons.OK, MessageBoxIcon.Error);
            WebSetup.OpenExternal("https://developer.microsoft.com/microsoft-edge/webview2/");
            Close();
            return;
        }

        var core = _web.CoreWebView2;
        WebSetup.Configure(core, openPopup: ShowPopup);
        await core.AddScriptToExecuteOnDocumentCreatedAsync(BridgeScript);
        await core.AddScriptToExecuteOnDocumentCreatedAsync(InitialSettingScript(_initialBackground));

        core.WebMessageReceived += OnWebMessage;

        // ページ遷移・再読み込みの間は、いったんバックグラウンド入力を止める(ページ側が描画時に再設定する)
        core.NavigationStarting += (_, e) =>
        {
            if (WebSetup.IsOwn(e.Uri)) _hook.Configure(false, Array.Empty<string>());
        };

        // 録音(マイク)は自サイトにだけ許可
        core.PermissionRequested += (_, e) =>
        {
            if (!WebSetup.IsOwn(e.Uri)) e.State = CoreWebView2PermissionState.Deny;
            else if (e.PermissionKind == CoreWebView2PermissionKind.Microphone) e.State = CoreWebView2PermissionState.Allow;
        };

        core.ProcessFailed += (_, e) =>
        {
            if (e.ProcessFailedKind == CoreWebView2ProcessFailedKind.RenderProcessExited)
                BeginInvoke(() => _web.CoreWebView2?.Reload());
        };

        core.Navigate(DeepLinkToUrl(_startLink) ?? WebSetup.HomeUrl);
    }

    private void ShowPopup(string url)
    {
        if (_env is null) return;
        new PopupForm(_env, url, Icon).Show(this);
    }

    private void OnWebMessage(object? sender, CoreWebView2WebMessageReceivedEventArgs e)
    {
        if (!WebSetup.IsOwn(e.Source)) return;
        try
        {
            using var doc = JsonDocument.Parse(e.WebMessageAsJson);
            var root = doc.RootElement;
            switch (root.GetProperty("type").GetString())
            {
                case "bgkeys":
                    var enabled = root.GetProperty("enabled").GetBoolean();
                    var keys = root.GetProperty("keys").EnumerateArray()
                        .Select(x => x.GetString())
                        .Where(x => !string.IsNullOrEmpty(x))
                        .Cast<string>()
                        .ToList();
                    _bgEnabled = enabled;
                    _hook.Configure(enabled, keys);
                    break;

                case "open":
                    WebSetup.OpenExternal(root.GetProperty("url").GetString());
                    break;
            }
        }
        catch
        {
            // 不正なメッセージは無視
        }
    }

    private void OnCombo(string combo, bool repeat)
    {
        // このアプリが前面のときは、ページ自身のキー処理が鳴らすので二重にならないようにする
        if (NativeMethods.IsOwnProcessForeground()) return;
        _web.CoreWebView2?.PostWebMessageAsJson(
            JsonSerializer.Serialize(new { type = "key", combo, repeat }));
    }

    /// <summary>2つ目の起動(soundbutton://... や再起動)から転送されたメッセージを処理します。</summary>
    public void HandleExternalMessage(string message)
    {
        if (message.Length > 8192) return;

        if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal;
        Show();
        Activate();
        BringToFront();
        NativeMethods.SetForegroundWindow(Handle);

        var url = DeepLinkToUrl(message);
        if (url != null) _web.CoreWebView2?.Navigate(url);
    }

    /// <summary>soundbutton://auth?code=... → https://soundbutton.example/index.html?code=...</summary>
    private static string? DeepLinkToUrl(string? link)
    {
        const string prefix = "soundbutton://auth";
        if (string.IsNullOrEmpty(link) || !link.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) return null;
        var rest = link[prefix.Length..].TrimStart('/');
        if (rest.Length > 0 && rest[0] != '?' && rest[0] != '#') return null;
        return WebSetup.HomeUrl + rest;
    }
}

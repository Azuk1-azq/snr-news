using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace SoundButton;

/// <summary>利用規約・プライバシーポリシーなど、window.open で開かれるページ用の小窓。</summary>
internal sealed class PopupForm : Form
{
    private readonly WebView2 _web = new() { Dock = DockStyle.Fill };

    public PopupForm(CoreWebView2Environment env, string url, Icon? icon)
    {
        Text = "SoundButton EX";
        ClientSize = new Size(960, 780);
        StartPosition = FormStartPosition.CenterParent;
        if (icon != null) Icon = icon;
        Controls.Add(_web);

        Shown += async (_, _) =>
        {
            await _web.EnsureCoreWebView2Async(env);
            var core = _web.CoreWebView2;
            WebSetup.Configure(core,
                openPopup: u => core.Navigate(u),   // 小窓の中ではそのまま遷移
                onNavigateHome: Close);             // 「アプリへ戻る」で小窓を閉じる
            core.DocumentTitleChanged += (_, _) => Text = core.DocumentTitle;
            core.Navigate(url);
        };
    }
}

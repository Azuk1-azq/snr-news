using System.IO.Pipes;
using System.Text;

namespace SoundButton;

internal static class Program
{
    private static readonly string PipeName = "SoundButton." + Environment.UserName;

    [STAThread]
    private static void Main(string[] args)
    {
        var deepLink = args.FirstOrDefault(a => a.StartsWith("soundbutton:", StringComparison.OrdinalIgnoreCase));

        // 多重起動はしない。2つ目はログイン復帰用のURLを1つ目に渡して終了する
        using var mutex = new Mutex(true, @"Local\SoundButton.SingleInstance", out bool isFirst);
        if (!isFirst)
        {
            SendToRunningInstance(deepLink ?? "show");
            return;
        }

        ProtocolRegistrar.Register();
        ApplicationConfiguration.Initialize();

        // 初回だけ、バックグラウンドで動かすかを必ず選んでもらう(閉じる・キャンセルは不可)
        var settings = AppSettings.Load();
        if (settings.BackgroundChoice is null)
        {
            settings.BackgroundChoice = AskBackgroundChoice();
            settings.Save();
        }

        var form = new MainForm(deepLink, settings.BackgroundChoice.Value);
        form.Shown += (_, _) => StartPipeServer(form);
        Application.Run(form);
    }

    private static bool AskBackgroundChoice()
    {
        var yes = new TaskDialogButton("バックグラウンドで動かす");
        var no = new TaskDialogButton("動かさない");
        var page = new TaskDialogPage
        {
            Caption = "SoundButton EX",
            Heading = "バックグラウンドで動作させますか？",
            Text =
                "オンにすると、他のアプリやゲームを使っている間も、割り当てたキーで音を鳴らせます。\n\n" +
                "・割り当てたキー以外の入力は、読み取りも保存もしません。\n" +
                "・ウィンドウの「×」を押しても、タスクトレイで動き続けます。\n" +
                "・完全に終了するには、タスクトレイのアイコンを右クリックして「終了」を選びます。\n\n" +
                "この設定は、あとから設定画面で変更できます。",
            Icon = TaskDialogIcon.Information,
            AllowCancel = false,
            Buttons = { yes, no },
            DefaultButton = yes,
        };
        return TaskDialog.ShowDialog(page) == yes;
    }

    private static void SendToRunningInstance(string message)
    {
        try
        {
            using var client = new NamedPipeClientStream(".", PipeName, PipeDirection.Out);
            client.Connect(3000);
            using var writer = new StreamWriter(client, new UTF8Encoding(false)) { AutoFlush = true };
            writer.WriteLine(message);
        }
        catch
        {
            // 1つ目がまだ準備中など。何もしない
        }
    }

    private static void StartPipeServer(MainForm form)
    {
        _ = Task.Run(async () =>
        {
            while (!form.IsDisposed)
            {
                try
                {
                    await using var server = new NamedPipeServerStream(
                        PipeName, PipeDirection.In, 1, PipeTransmissionMode.Byte, PipeOptions.Asynchronous);
                    await server.WaitForConnectionAsync();
                    using var reader = new StreamReader(server, Encoding.UTF8);
                    var line = await reader.ReadLineAsync();
                    if (line is { Length: > 0 and <= 8192 } && !form.IsDisposed)
                        form.BeginInvoke(() => form.HandleExternalMessage(line));
                }
                catch (ObjectDisposedException) { return; }
                catch { await Task.Delay(200); }
            }
        });
    }
}

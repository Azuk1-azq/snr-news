using Microsoft.Win32;

namespace SoundButton;

/// <summary>ログイン(Google/Discord)後にブラウザから戻ってくるための soundbutton:// を登録します(管理者権限は不要)。</summary>
internal static class ProtocolRegistrar
{
    public static void Register()
    {
        try
        {
            var exe = Environment.ProcessPath;
            if (string.IsNullOrEmpty(exe)) return;

            var command = $"\"{exe}\" \"%1\"";
            using var cmdKey = Registry.CurrentUser.CreateSubKey(@"Software\Classes\soundbutton\shell\open\command");
            if (cmdKey is null) return;
            if ((cmdKey.GetValue(null) as string) == command) return;   // 登録済み

            using var root = Registry.CurrentUser.CreateSubKey(@"Software\Classes\soundbutton");
            root?.SetValue(null, "URL:SoundButton");
            root?.SetValue("URL Protocol", "");
            cmdKey.SetValue(null, command);
        }
        catch
        {
            // 登録できなくてもアプリ自体は動く(OAuthの戻りだけ使えない)
        }
    }
}

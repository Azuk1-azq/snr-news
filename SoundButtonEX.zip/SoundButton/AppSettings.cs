using System.Text.Json;

namespace SoundButton;

/// <summary>アプリ側の設定(初回のバックグラウンド動作の選択だけ)。</summary>
internal sealed class AppSettings
{
    /// <summary>null = まだ選んでいない(初回起動)。</summary>
    public bool? BackgroundChoice { get; set; }

    private static string FilePath => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "SoundButton", "settings.json");

    public static AppSettings Load()
    {
        try
        {
            if (File.Exists(FilePath))
                return JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(FilePath)) ?? new AppSettings();
        }
        catch { /* 壊れていたら初回扱い */ }
        return new AppSettings();
    }

    public void Save()
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(FilePath)!);
            File.WriteAllText(FilePath, JsonSerializer.Serialize(this));
        }
        catch { /* 保存できなくても動作は続ける */ }
    }
}

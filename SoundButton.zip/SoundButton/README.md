# SoundButton (Windows版)

既存の `index.html` を WebView2 で包んだ、C# (.NET 8 / WinForms) 製のWindowsアプリです。
他のアプリやゲームを使っている間も、割り当てたキーで音を鳴らせます。

## ビルド

必要なもの: [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0) (Windows)

```
build.bat
```

または

```
dotnet publish SoundButton.csproj -c Release -o publish
```

`publish\SoundButton.exe` が完成品です(単一exe)。
実行には .NET 8 Desktop Runtime と WebView2 ランタイム(Windows 11には標準搭載)が必要です。
.NETが入っていない環境にも配る場合は、次の自己完結版で作ってください(サイズは大きくなります)。

```
dotnet publish SoundButton.csproj -c Release -p:SelfContained=true -p:EnableCompressionInSingleFile=true -o publish-full
```

## 追加で置くファイル

`Web/` フォルダの中身は、ビルド時にexeへ埋め込まれます。
今回は index / terms / privacy / errors を入れてあります。次のファイルも `Web/` に入れてからビルドしてください。

- `copyright.html`
- `manifest.webmanifest`
- `icon-dark-64.png`, `icon-light-64.png`, `icon-dark-180.png` など、HTMLが参照している画像

HTMLを更新したときは、`Web/` のファイルを差し替えて、もう一度ビルドします。

## 仕組み

- アプリは `https://soundbutton.example/` という仮想ホストで、埋め込んだHTMLを表示します(実際の通信は発生しません)。
  secure contextなので、IndexedDB・マイク録音・Supabaseのログインがそのまま動きます。
- HTMLにあらかじめ書かれていた `window.electronApp` (`setBackgroundKeys` / `onGlobalKey` / `openExternal`) を、
  アプリ側で用意しています。HTMLの改造は不要です。
- キー検出は低レベルキーボードフックです。
  - 設定で「バックグラウンドでのキー入力」がオンで、割り当てキーがあるときだけ有効になります。
  - 割り当てたキー(と修飾キー)と一致しない入力は、その場で破棄します。保存も送信もしません。
  - キー入力は握りつぶさず、他のアプリにもそのまま届きます。
  - このアプリが前面のときは、ページ自身のキー処理に任せます(二重再生の防止)。
  - キー名はHTMLの `comboOf()` と同じ形式(`KeyA`、`Ctrl+Digit1` など。修飾キーは1つまで、Winキー不可)です。
- 「×」でアプリは終了します。バックグラウンドで使うときは最小化してください(HTML内の説明文と同じ動作です)。
- 多重起動はしません。2つ目の起動は、1つ目のウィンドウを前面に出して終了します。

## ログイン(Google / Discord)

HTMLは、アプリ版では `soundbutton://auth` に戻る設定になっています。

1. 初回起動時に、`soundbutton://` をユーザー単位(HKCU)で登録します(管理者権限は不要)。
2. SupabaseのダッシュボードのAuthentication → URL Configuration → Redirect URLs に、`soundbutton://auth` を追加してください。
3. ブラウザでログインが終わると、アプリに戻ってセッションが確立されます。

exeを別の場所へ移したら、一度起動し直すと、登録が更新されます。

## 注意

- 管理者権限で動いているゲームやアプリが前面のときは、WindowsのUIPIの仕様で、キー入力を検出できません。その場合は、SoundButtonも管理者として起動してください。
- グローバルキーフックを使うため、セキュリティソフトが警告することがあります。署名のないexeは、SmartScreenの警告も出ます。
- データ(IndexedDB・ログイン状態)は `%LOCALAPPDATA%\SoundButton\WebView2` に保存されます。
- アプリ版の説明を、プライバシーポリシーの記載(バックグラウンド入力は任意・一致しない入力は破棄)と合わせてあります。
